<?php wp_footer(); ?>
<div id="to_top"></div>
</body></html>